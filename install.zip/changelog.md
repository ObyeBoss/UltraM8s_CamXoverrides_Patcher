### 21.07.2023
* MMTEX update
* Support for KSU & canary Magisk